﻿using Microsoft.AspNetCore.Mvc;

namespace Project_of_Enterprise.Controllers
{
    public class Front_PageController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }

        public ViewResult login()
        {
            return View();
        }

        public ViewResult Registration()
        {
            return View();
        }

        public ViewResult AboutUs()
        {
            return View();
        }
    }
}
